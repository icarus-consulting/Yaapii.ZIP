# Purpose
This is a sample zip to test the XML tree building logic.